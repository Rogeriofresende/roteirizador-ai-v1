import React, { useRef, useEffect, useState } from 'react';
import { PLATFORM_OPTIONS } from '../../constants';
import { responsiveGridClasses, touchButtonClasses } from '../../design-system/tokens';
import { useOverflowDetection, getResponsiveGridCols } from '../../utils/responsive';

type Platform = 'YouTube' | 'Instagram' | 'TikTok' | '';

interface PlatformSelectorProps {
  selectedPlatform: Platform;
  onPlatformChange: (platform: Platform) => void;
  disabled?: boolean;
}

const PlatformSelector: React.FC<PlatformSelectorProps> = ({ 
  selectedPlatform, 
  onPlatformChange, 
  disabled 
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [containerSize, setContainerSize] = useState({ width: 0, scrollWidth: 0 });
  const [hasOverflow, setHasOverflow] = useState(false);
  
  // Enhanced overflow detection with resize observer
  useEffect(() => {
    const updateSize = () => {
      if (containerRef.current) {
        const width = containerRef.current.clientWidth;
        const scrollWidth = containerRef.current.scrollWidth;
        const overflow = scrollWidth > width;
        
        setContainerSize({ width, scrollWidth });
        setHasOverflow(overflow);
        
        // Debug overflow in development
        if (process.env.NODE_ENV === 'development' && overflow) {
          console.warn('🚨 PlatformSelector: Layout overflow detected!', {
            platformCount: PLATFORM_OPTIONS.length,
            containerWidth: width,
            scrollWidth: scrollWidth,
            overflow: scrollWidth - width
          });
        }
      }
    };
    
    // Initial size check
    updateSize();
    
    // Setup resize observer
    const resizeObserver = new ResizeObserver(updateSize);
    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }
    
    // Window resize fallback
    window.addEventListener('resize', updateSize);
    
    return () => {
      resizeObserver.disconnect();
      window.removeEventListener('resize', updateSize);
    };
  }, []);
  
  // Adaptive grid classes based on container size
  const getAdaptiveGridClasses = () => {
    const baseClasses = "grid gap-2 w-full";
    
    // If overflow detected, use smaller grid
    if (hasOverflow) {
      return `${baseClasses} grid-cols-2 sm:grid-cols-3 lg:grid-cols-4`;
    }
    
    // Standard responsive grid - improved to prevent overflow
    return `${baseClasses} grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-${PLATFORM_OPTIONS.length}`;
  };
  
  // Adaptive button classes based on overflow state
  const getAdaptiveButtonClasses = (option: any) => {
    const baseClasses = `
      border rounded-md font-medium text-center
      transition-all duration-200 
      focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2
      min-h-[44px] flex items-center justify-center
      ${selectedPlatform === option.label
        ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
        : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50 hover:border-gray-400'
      }
      ${disabled 
        ? 'opacity-50 cursor-not-allowed' 
        : 'hover:shadow-sm active:transform active:scale-[0.98]'
      }
    `;
    
    // Adaptive text size and padding based on overflow
    if (hasOverflow) {
      return `${baseClasses} text-xs px-2 py-1`;
    }
    
    return `${baseClasses} text-sm px-3 py-2`;
  };
  
  return (
    <div className="mb-4">
      <label className="block text-sm font-medium text-gray-700 mb-2">
        Plataforma <span className="text-red-500">*</span>
      </label>
      
      {/* Adaptive responsive grid with overflow protection */}
      <div 
        ref={containerRef}
        className={getAdaptiveGridClasses()}
        style={{
          // Force container to not exceed its parent
          maxWidth: '100%',
          overflow: 'hidden'
        }}
        role="group"
        aria-label="Seleção de plataforma"
      >
        {PLATFORM_OPTIONS.map((option) => (
          <button
            key={option.value}
            type="button"
            onClick={() => onPlatformChange(option.label as Platform)}
            disabled={disabled}
            aria-pressed={selectedPlatform === option.label}
            className={getAdaptiveButtonClasses(option)}
            style={{
              // Ensure buttons don't exceed container
              minWidth: 0,
              maxWidth: '100%'
            }}
          >
            <span className="truncate">
              {option.label}
            </span>
          </button>
        ))}
      </div>
      
      {/* Development overflow warning */}
      {process.env.NODE_ENV === 'development' && hasOverflow && (
        <div className="mt-2 p-2 bg-yellow-50 border border-yellow-200 rounded text-xs text-yellow-800">
          ⚠️ Layout overflow corrigido automaticamente 
          <span className="text-gray-600 ml-2">
            ({containerSize.scrollWidth}px → {containerSize.width}px)
          </span>
        </div>
      )}
      
      {/* Success indicator when overflow is resolved */}
      {process.env.NODE_ENV === 'development' && !hasOverflow && containerSize.width > 0 && (
        <div className="mt-1 text-xs text-green-600 opacity-75">
          ✅ Layout responsivo funcionando ({containerSize.width}px)
        </div>
      )}
    </div>
  );
};

export default PlatformSelector;
